💻 Many pirates steal the plugins that I post and don’t even open them for viewing)

So know this product was downloaded from the babiato forum and provided by Qurel

💻 How to install

You simply need to download the files, unzip the package and then copy the "payment-blocks" folder inside of your plugins folder of the main product installation.

After that, you can go inside of your admin panel, go to the Plugins management section and enable your new plugin.