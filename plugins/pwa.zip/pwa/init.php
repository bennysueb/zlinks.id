<?php

/* Load all the related plugin files */
require_once \Altum\Plugin::get('pwa')->path . 'Pwa.php';

/* Functions */
if(!function_exists('pwa_generate_manifest')) {
    function pwa_generate_manifest($name, $short_name, $description, $theme_color, $icon_url)
    {
        $manifest = [
            'start_url' => SITE_URL,
            'scope' => SITE_URL,
            'name' => $name,
            'short_name' => $short_name,
            'description' => $description,
            'theme_color' => $theme_color,
            'background_color' => $theme_color,
            'display' => 'standalone',
            'icons' => [],
        ];

        if ($icon_url) {
            $manifest['icons'][] = [
                'src' => $icon_url,
                'sizes' => '512x512',
                'type' => 'image/png',
                'purpose' => 'any maskable'
            ];
        }

        return json_encode($manifest);
    }
}

if(!function_exists('pwa_save_manifest')) {
    function pwa_save_manifest($manifest_content) {
        file_put_contents(\Altum\Uploads::get_full_path('pwa') . 'manifest.json', $manifest_content);
    }
}
