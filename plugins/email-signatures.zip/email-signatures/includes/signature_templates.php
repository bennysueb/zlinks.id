<?php

return [
    'plain_text' => [
        'icon' => 'fas fa-signature'
    ],
    'mars' => [
        'icon' => 'fas fa-globe-africa'
    ],
    'mercury' => [
        'icon' => 'fas fa-globe-asia'
    ],
];
