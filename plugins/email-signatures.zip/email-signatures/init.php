<?php

/* Load all the related plugin files */
require_once \Altum\Plugin::get('email-signatures')->path . 'EmailSignatures.php';
